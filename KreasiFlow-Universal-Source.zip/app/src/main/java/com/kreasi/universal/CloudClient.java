package com.kreasi.universal;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.zip.*;
import javax.net.ssl.HttpsURLConnection;
import android.util.Base64;
import android.media.MediaMetadataRetriever;

/** GitHub REST bridge. Credentials never enter the payload or signed artifact URL. */
final class CloudClient {
    static final String REPO="alfianzikri63-blip/BedahKlasik", WORKFLOW="kfu-cloud-render.yml";
    static final String ROOT="https://api.github.com/repos/"+REPO;
    static final long LIMIT=300L*1024*1024;
    static HttpsURLConnection connect(String url,String token,String method)throws Exception{
        URL u=new URL(url);if(!"https".equals(u.getProtocol()))throw new IOException("HTTPS wajib");
        if(!token.isEmpty()&&!"api.github.com".equals(u.getHost()))throw new IOException("Host API tidak valid");
        HttpsURLConnection c=(HttpsURLConnection)u.openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(20000);c.setReadTimeout(60000);c.setRequestMethod(method);
        if(!token.isEmpty()){c.setRequestProperty("Authorization","Bearer "+token);c.setRequestProperty("Accept","application/vnd.github+json");c.setRequestProperty("X-GitHub-Api-Version","2022-11-28");}return c;
    }
    static JSONObject request(String token,String path,JSONObject payload)throws Exception{
        HttpsURLConnection c=connect(ROOT+path,token,payload==null?"GET":"POST");
        try{if(payload!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");try(OutputStream o=c.getOutputStream()){o.write(payload.toString().getBytes(StandardCharsets.UTF_8));}}
            int n=c.getResponseCode();if(n<200||n>=300)throw new IOException("GitHub HTTP "+n+" — cek token, izin Actions, workflow dan branch main");if(n==204)return new JSONObject();
            try(InputStream i=c.getInputStream();ByteArrayOutputStream b=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int x;while((x=i.read(buf))!=-1){if(b.size()+x>4*1024*1024)throw new IOException("Respons terlalu besar");b.write(buf,0,x);}String s=b.toString("UTF-8");return s.trim().isEmpty()?new JSONObject():new JSONObject(s);}
        }finally{c.disconnect();}
    }
    static String payload(JSONObject p)throws Exception{
        ByteArrayOutputStream out=new ByteArrayOutputStream();EpisodeBuilder.writeZip(p,out);String s=Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);if(s.length()>60000)throw new IOException("Episode terlalu besar untuk workflow dispatch (60 KB base64). Ringkas model atau gunakan ekspor manual.");return s;
    }
    static JSONObject dispatch(String token,String job,String data)throws Exception{return request(token,"/actions/workflows/"+WORKFLOW+"/dispatches",new JSONObject().put("ref","main").put("inputs",new JSONObject().put("job_id",job).put("episode_b64",data)));}
    static JSONObject status(String token,String job,long id)throws Exception{
        if(id>0){JSONObject r=request(token,"/actions/runs/"+id,null);if(!("KFU "+job).equals(r.optString("display_title")))throw new IOException("Run bukan milik job ini");return r;}
        JSONArray runs=request(token,"/actions/workflows/"+WORKFLOW+"/runs?event=workflow_dispatch&branch=main&per_page=50",null).getJSONArray("workflow_runs");for(int i=0;i<runs.length();i++){JSONObject r=runs.getJSONObject(i);if(("KFU "+job).equals(r.optString("display_title")))return r;}return new JSONObject();
    }
    static void download(String token,String job,long run,File dest)throws Exception{
        JSONObject r=status(token,job,run);if(!"completed".equals(r.optString("status"))||!"success".equals(r.optString("conclusion")))throw new IOException("Workflow belum berhasil");
        long resolvedRun=r.optLong("id");if(resolvedRun<=0)throw new IOException("Run ID tidak valid");JSONArray a=request(token,"/actions/runs/"+resolvedRun+"/artifacts?per_page=100",null).getJSONArray("artifacts");long id=0;for(int i=0;i<a.length();i++){JSONObject v=a.getJSONObject(i);if(("kfu-"+job).equals(v.optString("name"))&&!v.optBoolean("expired")){id=v.getLong("id");break;}}if(id==0)throw new IOException("Artifact belum tersedia atau kedaluwarsa");
        HttpsURLConnection api=connect(ROOT+"/actions/artifacts/"+id+"/zip",token,"GET");File tmp=File.createTempFile("cloud-",".mp4",dest.getParentFile());
        try{int status=api.getResponseCode();if(status!=302&&status!=301&&status!=307)throw new IOException("Artifact HTTP "+status);String link=api.getHeaderField("Location");if(link==null)throw new IOException("Link artifact kosong");HttpsURLConnection data=connect(link,"","GET");try{if(data.getResponseCode()!=200)throw new IOException("Unduh artifact gagal");boolean found=false;long total=0;int count=0;try(ZipInputStream z=new ZipInputStream(data.getInputStream())){ZipEntry e;byte[] buf=new byte[32768];while((e=z.getNextEntry())!=null){if(++count>50)throw new IOException("Artifact tidak valid");boolean match=e.getName().equals("video.mp4")&&!e.isDirectory();if(match&&found)throw new IOException("MP4 ganda");try(OutputStream o=match?new FileOutputStream(tmp):null){int n;while((n=z.read(buf))!=-1){total+=n;if(total>LIMIT)throw new IOException("Artifact terlalu besar");if(o!=null)o.write(buf,0,n);}}if(match)found=true;z.closeEntry();}}if(!found||tmp.length()<12)throw new IOException("MP4 tidak ditemukan");}finally{data.disconnect();}
            MediaMetadataRetriever mm=new MediaMetadataRetriever();try{mm.setDataSource(tmp.getAbsolutePath());String dur=mm.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);if(!"yes".equals(mm.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO))||!"yes".equals(mm.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO))||dur==null||Long.parseLong(dur)<1000)throw new IOException("MP4 tidak memiliki video dan audio valid");}finally{mm.release();}
            if(!tmp.renameTo(dest))throw new IOException("Gagal menyimpan MP4");
        }finally{api.disconnect();tmp.delete();}
    }
}
