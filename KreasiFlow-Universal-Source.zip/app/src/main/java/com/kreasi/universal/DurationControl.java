package com.kreasi.universal;
import org.json.*;
import java.util.regex.*;
final class DurationControl {
 static String scope(String text,int target){return target==0?text:text+"\n[KFU_TARGET_SECONDS="+target+"]";}
 static int target(String scope){Matcher m=Pattern.compile("\\[KFU_TARGET_SECONDS=(15|30|45|60|90|120)\\]$").matcher(scope.trim());return m.find()?Integer.parseInt(m.group(1)):0;}
 static String guide(String scope){int n=target(scope);return n==0?"":"\nTarget durasi pengguna "+n+" detik (perkiraan, audio aktual menentukan). Utamakan narasi bersih tanpa timestamp/nomor adegan. Untuk Classic target sekitar "+Math.max(8,Math.round((n-2)*2.2f))+" kata, tanpa pengulangan. Untuk mode scene ikuti batas kata dan jumlah adegan yang ditetapkan katalog; pilih jumlah adegan agar mendekati target. Jangan mengklaim durasi pasti.";}
 static void scalePlan(JSONObject plan,int target,boolean shots)throws JSONException{
   if(target==0)return;if(target>30)throw new IllegalArgumentException("Mode scene mendukung target 15/30 detik");JSONArray scenes=plan.getJSONArray("scenes");double budget=target==30?27:target-1;double d=budget/scenes.length();if(d>15)throw new IllegalArgumentException("Tambahkan adegan untuk target durasi ini");
   for(int i=0;i<scenes.length();i++){JSONObject s=scenes.getJSONObject(i);double old=s.getDouble("duration");if(shots){JSONArray a=s.getJSONArray("shots");for(int j=0;j<a.length();j++){JSONObject shot=a.getJSONObject(j);shot.put("until",j==a.length()-1?d:shot.getDouble("until")/old*d);}}s.put("duration",d);}
 }
}
