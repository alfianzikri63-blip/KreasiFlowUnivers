package com.kreasi.universal;
import org.json.*;
import java.io.IOException;
import java.util.regex.Pattern;

/** Data-only plan. The model never writes or executes renderer code. */
final class SceneDirector {
    static JSONObject schema() throws JSONException {
        JSONObject text=new JSONObject().put("type","string");
        JSONObject scene=new JSONObject().put("type","object").put("properties",new JSONObject().put("type",new JSONObject().put("type","string").put("enum",new JSONArray().put("warehouse").put("delivery").put("gears").put("propeller").put("retail"))).put("title",text).put("narration",text)).put("required",new JSONArray().put("type").put("title").put("narration"));
        return new JSONObject().put("type","object").put("properties",new JSONObject().put("supported",new JSONObject().put("type","boolean")).put("reason",text).put("title",text).put("scenes",new JSONObject().put("type","array").put("items",scene))).put("required",new JSONArray().put("supported").put("reason").put("title").put("scenes"));
    }
    static JSONObject generate(String key,String model,String topic,String scope,String skill)throws Exception {
        String prompt="Buat draft narasi edukasi Indonesia untuk prototipe Bedah Klasik Scene Lab. Output hanya JSON sesuai schema. Bukan kode. Pilih topik otomatis bila kosong. Katalog TERBATAS: warehouse = rak gudang, kardus bergerak di conveyor, scanner, forklift; delivery = truk membawa muatan di jalan; gears = dua roda gigi berputar; propeller = baling-baling pada dudukan dan partikel skematis udara mengalir ke belakang (bukan model pesawat utuh atau simulasi fluida); retail = troli dan barang dipindah ke rak toko secara ilustratif. Tidak tersedia organ, pesawat utuh atau proses spesifik di luar katalog. Jika topik tidak bisa digambarkan secara jujur dengan katalog, supported=false, reason jelaskan keterbatasan, scenes=[]; jangan ubah topik diam-diam. Jika sesuai, supported=true, title maksimal 24 karakter, 1 sampai 3 scene, title scene maksimal 24 karakter, narration satu kalimat maksimal 100 karakter (8–14 kata), tanpa timestamp, kode scene, SFX, markdown atau petunjuk kamera. Narasi harus cocok dengan gerakan yang benar-benar ada. Tidak mengklaim SOP merek atau sumber terverifikasi. Seluruh hasil simulasi draft. Skill asli berikut sebagai arahan; bila tidak bisa memenuhi, laporkan batasan.\nSKILL:\n"+skill+"\nTOPIK: "+topic+"\nBATASAN: "+scope;
        return compile(AiClient.generate(key,model,prompt,schema()));
    }
    static String clean(JSONObject o,String name,int max)throws Exception {
        String v=o.getString(name).trim(); if(v.isEmpty()||v.length()>max||v.matches("(?s).*[\\r\\n{}<>\\[\\]].*")||Pattern.compile("\\(\\d{1,2}:\\d{2}\\)|(?i)^(scene|beat|adegan|vo|narasi|sfx)\\s*[:\\d]").matcher(v).find())throw new IOException("Teks scene tidak valid: "+name);return v;
    }
    static JSONArray vec(double a,double b,double c)throws JSONException{return new JSONArray().put(a).put(b).put(c);}
    static JSONObject shot(double end,JSONArray eye,JSONArray target,double width)throws JSONException{return new JSONObject().put("until",end).put("eye",eye).put("target",target).put("width",width);}
    static JSONObject compile(JSONObject draft)throws Exception{
        if(!draft.getBoolean("supported"))throw new IOException("Katalog belum mendukung topik ini: "+draft.optString("reason"));
        JSONArray items=draft.getJSONArray("scenes"),scenes=new JSONArray();if(items.length()<1||items.length()>3)throw new IOException("Jumlah scene harus 1–3");
        for(int i=0;i<items.length();i++){JSONObject x=items.getJSONObject(i);String type=x.getString("type");JSONArray shots=new JSONArray();double duration=7.5;
            switch(type){case "warehouse":shots.put(shot(3.75,vec(13,13,17),vec(0,.65,0),16.8)).put(shot(duration,vec(9,8,12),vec(.2,.65,2.05),11.5));break;case "delivery":shots.put(shot(3.75,vec(12,12,17),vec(0,.6,0),16.8)).put(shot(duration,vec(8,7,13),vec(2.1,.9,.8),11.8));break;case "gears":shots.put(shot(duration,vec(6,12,10),vec(0,.55,0),9.7));break;case "propeller":shots.put(shot(3.75,vec(9,6,13),vec(0,2,0),10.0)).put(shot(duration,vec(12,5,7),vec(0,2.2,0),9.3));break;case "retail":shots.put(shot(3.75,vec(10,10,15),vec(0,1,-.4),12.6)).put(shot(duration,vec(8,6,14),vec(1.5,1.2,-1.6),8.0));break;default:throw new IOException("Aset belum tersedia: "+type);}
            scenes.put(new JSONObject().put("type",type).put("duration",duration).put("title",clean(x,"title",24)).put("narration",clean(x,"narration",100)).put("shots",shots));}
        return new JSONObject().put("schema",2).put("title",clean(draft,"title",24)).put("scenes",scenes);
    }
}
