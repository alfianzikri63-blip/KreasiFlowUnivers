package com.kreasi.universal;

import android.app.*;
import android.content.*;
import android.os.*;
import java.util.regex.*;

/** Foreground data-sync service for active network production. Stage units, not render-time estimates. */
public final class ProductionProgress extends Service {
    private static final String CHANNEL="kfu_production_v1";
    private static final int ACTIVE=24501, RESULT=24502;
    private static volatile boolean running=false;
    private static ProductionProgress instance;
    private static volatile String title="KreasiFlow Universal", step="Menyiapkan produksi";
    private static volatile int total=0, done=0;
    static boolean busy(){return running;}
    static int completed(String s,int max,int fallback){
        if(s.startsWith("MP4 draft tersedia")||s.startsWith("MP4 Lab tersedia"))return max;
        if(s.startsWith("Auto Repair")||s.startsWith("Motion Repair"))return max==5?1:0;
        Matcher m=Pattern.compile("^(\\d+)/(\\d+)").matcher(s);
        if(m.find()&&Integer.parseInt(m.group(2))==max)return Math.max(0,Math.min(max,Integer.parseInt(m.group(1))-1));
        return fallback;
    }
    static int stage(String s){return completed(s,total,-1);}
    static void begin(Context c,String name,int count){
        title=name;step="Menyiapkan produksi";total=count;done=0;running=true;
        NotificationManager nm=c.getSystemService(NotificationManager.class);channel(nm);nm.cancel(RESULT);
        try{Intent i=new Intent(c,ProductionProgress.class);if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i);else c.startService(i);}catch(RuntimeException e){running=false;}
    }
    static void update(Context c,String message,int count){if(!running)return;step=message;if(count>=0)done=count;try{c.getSystemService(NotificationManager.class).notify(ACTIVE,notification(c,true,true));}catch(RuntimeException ignored){}}
    static void refresh(Context c){if(running)update(c,step,-1);}
    static void finish(Context c,boolean success,String message){
        boolean wasRunning=running;running=false;step=message;if(success&&total>0)done=total;
        try{if(instance!=null){instance.stopForeground(true);instance.stopSelf();}NotificationManager nm=c.getSystemService(NotificationManager.class);nm.cancel(ACTIVE);if(wasRunning)nm.notify(RESULT,notification(c,false,success));}catch(RuntimeException ignored){}
    }
    private static void channel(NotificationManager nm){if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Progres produksi KFU",NotificationManager.IMPORTANCE_LOW));}
    private static Notification notification(Context c,boolean ongoing,boolean success){
        Intent open=new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi=PendingIntent.getActivity(c,245,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CHANNEL):new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle(title).setContentText(ongoing&&total>0?done+"/"+total+" tahap selesai · "+step:step).setStyle(new Notification.BigTextStyle().bigText(ongoing&&total>0?done+"/"+total+" tahap selesai (bukan waktu render)\n"+step:step)).setContentIntent(pi).setOnlyAlertOnce(true).setOngoing(ongoing).setAutoCancel(!ongoing).setVisibility(Notification.VISIBILITY_PRIVATE).setCategory(Notification.CATEGORY_PROGRESS);
        if(ongoing)b.setProgress(total,done,total==0);else if(success&&total>0)b.setProgress(total,total,false);
        return b.build();
    }
    @Override public int onStartCommand(Intent i,int flags,int id){
        instance=this;channel(getSystemService(NotificationManager.class));startForeground(ACTIVE,notification(this,true,true));
        if(!running)stopSelf();return START_NOT_STICKY;
    }
    @Override public IBinder onBind(Intent i){return null;}
    @Override public void onDestroy(){if(instance==this)instance=null;if(!running)stopForeground(true);super.onDestroy();}
}
