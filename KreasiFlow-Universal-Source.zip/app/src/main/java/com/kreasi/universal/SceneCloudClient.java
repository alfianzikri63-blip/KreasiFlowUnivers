package com.kreasi.universal;
import org.json.*;
import java.io.*;
import java.util.zip.*;
import javax.net.ssl.HttpsURLConnection;
import android.media.MediaMetadataRetriever;

final class SceneCloudClient {
    static final String WORKFLOW="kfu-universal-render.yml";
    static JSONObject dispatch(String token,String id,String skill,String mode,JSONObject plan,JSONObject audio)throws Exception{
        return CloudClient.request(token,"/actions/workflows/"+WORKFLOW+"/dispatches",new JSONObject().put("ref","main").put("inputs",new JSONObject().put("job_id",id).put("skill",skill).put("mode",mode).put("episode_b64","").put("scene_plan_json",plan==null?"":plan.toString()).put("audio_options",audio.toString())));
    }
    static JSONObject status(String token,String job,long id)throws Exception{
        if(id>0){JSONObject r=CloudClient.request(token,"/actions/runs/"+id,null);if(!("KFU Lab "+job).equals(r.optString("display_title")))throw new IOException("Run bukan milik job Scene Lab");return r;}
        JSONArray a=CloudClient.request(token,"/actions/workflows/"+WORKFLOW+"/runs?event=workflow_dispatch&branch=main&per_page=50",null).getJSONArray("workflow_runs");for(int i=0;i<a.length();i++){JSONObject r=a.getJSONObject(i);if(("KFU Lab "+job).equals(r.optString("display_title")))return r;}return new JSONObject();
    }
    static void download(String token,String job,long run,String mode,String expectedAdapter,File dest)throws Exception{
        JSONObject r=status(token,job,run);if(!"completed".equals(r.optString("status"))||!"success".equals(r.optString("conclusion")))throw new IOException("Run belum berhasil");long rid=r.getLong("id");
        JSONArray a=CloudClient.request(token,"/actions/runs/"+rid+"/artifacts?per_page=100",null).getJSONArray("artifacts");long aid=0;for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);if(("kfu-lab-"+rid).equals(x.optString("name"))&&!x.optBoolean("expired")){aid=x.getLong("id");break;}}if(aid==0)throw new IOException("Artifact Lab belum tersedia atau kedaluwarsa");
        File tmp=File.createTempFile("lab-",".mp4",dest.getParentFile());HttpsURLConnection api=CloudClient.connect(CloudClient.ROOT+"/actions/artifacts/"+aid+"/zip",token,"GET");
        try{int code=api.getResponseCode();if(code!=302&&code!=301&&code!=307)throw new IOException("Artifact HTTP "+code);String url=api.getHeaderField("Location");if(url==null)throw new IOException("URL artifact kosong");HttpsURLConnection dl=CloudClient.connect(url,"","GET");JSONObject report=null;boolean found=false;
            try{if(dl.getResponseCode()!=200)throw new IOException("Unduh gagal");try(ZipInputStream z=new ZipInputStream(dl.getInputStream())){ZipEntry e;long total=0;int count=0;byte[] buf=new byte[32768];while((e=z.getNextEntry())!=null){if(++count>50)throw new IOException("Artifact terlalu banyak file");boolean video="video.mp4".equals(e.getName())&&!e.isDirectory(),meta="status.json".equals(e.getName())&&!e.isDirectory();if(video&&found||meta&&report!=null)throw new IOException("Artifact duplikat");ByteArrayOutputStream b=meta?new ByteArrayOutputStream():null;try(OutputStream o=video?new FileOutputStream(tmp):null){int n;while((n=z.read(buf))!=-1){total+=n;if(total>CloudClient.LIMIT)throw new IOException("Artifact terlalu besar");if(o!=null)o.write(buf,0,n);if(b!=null){if(b.size()+n>65536)throw new IOException("Status terlalu besar");b.write(buf,0,n);}}}if(video)found=true;if(meta)report=new JSONObject(b.toString("UTF-8"));z.closeEntry();}}}finally{dl.disconnect();}
            if(!found||tmp.length()<12||report==null||!"DEMO_RENDERED_REVIEW_REQUIRED".equals(report.optString("status"))||!expectedAdapter.equals(report.optString("adapter")))throw new IOException("Artifact / laporan Lab tidak cocok");
            boolean needAudio="scene-episode".equals(mode);if(needAudio&&!report.optBoolean("audio_present"))throw new IOException("Laporan VO tidak valid");MediaMetadataRetriever mm=new MediaMetadataRetriever();try{mm.setDataSource(tmp.getAbsolutePath());String dur=mm.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);if(!"yes".equals(mm.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO))||dur==null||Long.parseLong(dur)<1000||(needAudio&&!"yes".equals(mm.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO))))throw new IOException("Track video/audio tidak valid");}finally{mm.release();}
            if(!tmp.renameTo(dest))throw new IOException("Gagal menyimpan MP4");
        }finally{api.disconnect();tmp.delete();}
    }
}
