package com.kreasi.universal;

import org.json.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

/** Normalize provider output before the UI consumes it. Never claim research was verified. */
final class DraftContract {
    static final String[] FIELDS={"topic","title","script","storyboard","visual","claims","source_candidates","caption","hashtags"};
    private static final String[] CORE={"topic","title","script","storyboard","visual"};
    private static final String[][] ALIASES={
        {"topik"},{"judul"},{"naskah","narration","voiceover"},{"beats","scenes"},
        {"model","visual_concept","konsep_visual"},{"facts","factual_claims","fakta","klaim"},
        {"sources","references","sumber","citations"},{"description","deskripsi"},{"tags","tagar"}
    };
    static JSONObject schema(String[] fields, int stages) throws JSONException {
        JSONObject props=new JSONObject(); JSONArray required=new JSONArray();
        for(String field:fields){props.put(field,new JSONObject().put("type","string"));required.put(field);}
        if(stages>0){JSONObject notes=new JSONObject();for(int i=0;i<stages;i++)notes.put(String.valueOf(i),new JSONObject().put("type","string"));props.put("stage_notes",new JSONObject().put("type","object").put("properties",notes));}
        return new JSONObject().put("type","object").put("properties",props).put("required",required);
    }
    private static String asText(Object v) throws JSONException {
        if(v==null||v==JSONObject.NULL)return "";
        if(v instanceof String){String s=((String)v).trim();return s.equalsIgnoreCase("null")?"":s;}
        if(v instanceof JSONArray){JSONArray a=(JSONArray)v;StringBuilder b=new StringBuilder();for(int i=0;i<a.length();i++){String s=asText(a.opt(i));if(!s.isEmpty()){if(b.length()>0)b.append("\n");b.append(s);}}return b.toString();}
        if(v instanceof JSONObject){JSONObject o=(JSONObject)v;StringBuilder b=new StringBuilder();Iterator<String> it=o.keys();while(it.hasNext()){String k=it.next(),s=asText(o.opt(k));if(!s.isEmpty()){if(b.length()>0)b.append("\n");b.append(k).append(": ").append(s);}}return b.toString();}
        if(v instanceof Number)return v.toString();
        return "";
    }
    static JSONObject normalize(JSONObject input) throws JSONException {
        JSONObject out=new JSONObject();
        for(int i=0;i<FIELDS.length;i++){
            String f=FIELDS[i], val=asText(input.opt(f));
            if(val.isEmpty())for(String alias:ALIASES[i]){val=asText(input.opt(alias));if(!val.isEmpty())break;}
            out.put(f,val);
        }
        JSONObject notes=new JSONObject(), original=input.optJSONObject("stage_notes");
        if(original!=null){Iterator<String> it=original.keys();while(it.hasNext()){String k=it.next();if(k.matches("[0-9]+"))notes.put(k,asText(original.opt(k)));}}
        out.put("stage_notes",notes);
        return out;
    }
    static String[] missing(JSONObject draft,String[] fields){ArrayList<String> result=new ArrayList<>();for(String f:fields)if(draft.optString(f,"").trim().isEmpty())result.add(f);return result.toArray(new String[0]);}
    static void mergeMissing(JSONObject draft,JSONObject repair,String[] fields)throws JSONException {
        for(String f:fields)if(draft.optString(f,"").trim().isEmpty()&&!repair.optString(f,"").trim().isEmpty())draft.put(f,repair.optString(f));
    }
    static JSONObject finish(JSONObject draft)throws JSONException,IOException {
        String[] missingCore=missing(draft,CORE);
        if(missingCore.length>0)throw new IOException("Konten utama belum lengkap: "+android.text.TextUtils.join(", ",missingCore)+". Coba generate kembali.");
        if(draft.optString("claims").trim().isEmpty())draft.put("claims","PERLU RISET — AI belum menyediakan daftar klaim. Jangan anggap fakta telah diverifikasi.");
        if(draft.optString("source_candidates").trim().isEmpty())draft.put("source_candidates","PERLU RISET — belum ada kandidat sumber yang diberikan AI.");
        if(draft.optString("caption").trim().isEmpty())draft.put("caption","BELUM DIBUAT — perlu dilengkapi.");
        if(draft.optString("hashtags").trim().isEmpty())draft.put("hashtags","BELUM DIBUAT — perlu dilengkapi.");
        return draft;
    }
    static JSONObject generate(String key,String model,String request,int stages)throws Exception {
        JSONObject draft=normalize(AiClient.generate(key,model,request,schema(FIELDS,stages)));
        String[] absent=missing(draft,FIELDS);
        if(absent.length>0){
            // One bounded recovery request; keep successful original fields.
            try{
                String repairPrompt="Lengkapi HANYA field kosong berikut dalam bahasa Indonesia: "+android.text.TextUtils.join(", ",absent)+". Pertahankan topik dan naskah yang sudah ada. Jangan mengarang sumber atau mengklaim verifikasi; jika tidak tahu tulis PERLU RISET. Kembalikan JSON.\nDraft yang sudah ada:\n"+draft.toString()+"\nInstruksi produksi:\n"+request;
                JSONObject repair=normalize(AiClient.generate(key,model,repairPrompt,schema(absent,0)));
                mergeMissing(draft,repair,absent);
            }catch(Exception e){
                if(missing(draft,CORE).length>0)throw e;
                // Optional fields may be explicitly pending if recovery failed.
            }
        }
        return finish(draft);
    }
}
