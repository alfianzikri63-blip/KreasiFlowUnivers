package com.kreasi.universal;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import javax.net.ssl.HttpsURLConnection;

final class AiClient {
    private static final String ALIAS="kfu_gemini_v2";
    private static javax.crypto.SecretKey localKey() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        if(!ks.containsAlias(ALIAS)) {
            KeyGenerator g=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
            g.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());g.generateKey();
        }
        return (javax.crypto.SecretKey)ks.getKey(ALIAS,null);
    }
    static void storeKey(SharedPreferences p,String key)throws Exception {
        if(key.length()>512||key.contains("\n")||key.contains("\r"))throw new IOException("API key tidak valid");
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,localKey());String data=Base64.encodeToString(c.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(c.doFinal(key.getBytes(StandardCharsets.UTF_8)),Base64.NO_WRAP);p.edit().putString("key",data).apply();
    }
    static String loadKey(SharedPreferences p)throws Exception {
        String data=p.getString("key","");if(data.isEmpty())return "";String[] a=data.split(":",2);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,localKey(),new GCMParameterSpec(128,Base64.decode(a[0],Base64.NO_WRAP)));return new String(c.doFinal(Base64.decode(a[1],Base64.NO_WRAP)),StandardCharsets.UTF_8);
    }
    private static String read(InputStream in)throws IOException {try(InputStream x=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=x.read(b))!=-1){if(out.size()+n>2*1024*1024)throw new IOException("Respons terlalu besar");out.write(b,0,n);}return out.toString("UTF-8");}}
    static JSONObject generate(String key,String model,String prompt)throws Exception {
        return generate(key,model,prompt,null);
    }
    static JSONObject generate(String key,String model,String prompt,JSONObject schema)throws Exception {
        if(!model.matches("gemini-[a-zA-Z0-9._-]{1,80}"))throw new IOException("Nama model tidak valid");
        HttpsURLConnection c=(HttpsURLConnection)new URL("https://generativelanguage.googleapis.com/v1beta/models/"+model+":generateContent").openConnection();
        c.setRequestMethod("POST");c.setInstanceFollowRedirects(false);c.setConnectTimeout(20000);c.setReadTimeout(120000);c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("x-goog-api-key",key);
        try {
            JSONObject config=new JSONObject().put("responseMimeType","application/json").put("maxOutputTokens",16384);
            if(schema!=null)config.put("responseJsonSchema",schema);
            JSONObject payload=new JSONObject().put("contents",new JSONArray().put(new JSONObject().put("parts",new JSONArray().put(new JSONObject().put("text",prompt))))).put("generationConfig",config);
            try(OutputStream out=c.getOutputStream()){out.write(payload.toString().getBytes(StandardCharsets.UTF_8));}
            int status=c.getResponseCode();if(status<200||status>=300){String hint=status==429?" — kuota/rate limit":status==401||status==403?" — cek API key dan izin":status==404?" — ganti model di Settings":status>=500?" — layanan sementara gagal":" — cek konfigurasi model";throw new IOException("HTTP "+status+hint);}
            JSONObject response=new JSONObject(read(c.getInputStream()));JSONArray candidates=response.optJSONArray("candidates");if(candidates==null||candidates.length()==0)throw new IOException("AI tidak mengembalikan kandidat");JSONObject candidate=candidates.getJSONObject(0);if(!"STOP".equals(candidate.optString("finishReason")))throw new IOException("Output tidak lengkap atau diblokir: "+candidate.optString("finishReason"));JSONArray parts=candidate.getJSONObject("content").getJSONArray("parts");StringBuilder result=new StringBuilder();for(int i=0;i<parts.length();i++){JSONObject part=parts.getJSONObject(i);if(!part.optBoolean("thought"))result.append(part.optString("text"));}String text=result.toString().trim();if(text.startsWith("```")){int start=text.indexOf('\n'),end=text.lastIndexOf("```");if(start>=0&&end>start)text=text.substring(start+1,end).trim();}return new JSONObject(text);
        }finally{c.disconnect();}
    }
}
