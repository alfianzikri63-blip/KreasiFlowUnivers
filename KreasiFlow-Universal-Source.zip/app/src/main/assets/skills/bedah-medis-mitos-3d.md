---
name: bedah-medis-mitos-3d
description: "Video 9:16 ±60 dtk \"bedah mitos medis\": hook mitos vs fakta, zoom ilustrasi anatomi 3D (kulit→otot merah→saraf), caption 1–2 kata kuning, pil label, pil hijau AMAN/merah WASPADA, CTA komentar."
---
# Bedah Medis Mitos 3D

Video edukasi kesehatan vertikal ±60 dtk yang membongkar **mitos sehari-hari** ("kedutan = ada yang kangen", "kesemutan = …") dengan kamera yang *menyelam* dari permukaan tubuh ke anatomi 3D (kulit → otot → saraf → serat), lalu ditutup tolok ukur **aman vs waspada** dan CTA komentar. Rasa: tenang, gelap hangat, dokter-yang-ramah, bukan menakut-nakuti.

## DNA Gaya
| Aspek | Nilai |
|---|---|
| Format | 720×1280 (render 1080×1920), 9:16, 30 fps, ±60 dtk |
| Pacing | Tidak ada hard cut. Perpindahan = zoom/morph kamera halus + crossfade. Ganti caption ±2 kali/dtk, ganti "layar info" tiap 5–8 dtk |
| VO | Perkiraan: pria/wanita tenang, jernih, ±2 kata/dtk (±115–125 kata/60 dtk), nyaris tanpa jeda hening, kata ganti "kamu", kalimat pendek (3–6 kata) |
| Caption | Poppins ExtraBold/Bold putih, 1–2 kata per tampil, kata kunci kuning, di ±63% tinggi layar, posisi X bergeser (kiri/tengah/kanan) |
| Palet | gelap hangat + merah otot + kuning aksen + hijau/merah status |
| Visual | Ilustrasi anatomi 3D semi-realistis (shading lembut, depth of field), satu subjek besar di tengah |
| Audio | Musik ambient/lo-fi tipis, whoosh halus tiap zoom, "pop" tiap pil muncul, "ding" untuk pil hijau, low-hit untuk pil WASPADA |

## Struktur per detik (60 dtk, ±2 dtk toleransi)
| Detik | Isi | Visual | Teks layar |
|---|---|---|---|
| 0–3 | **Hook**: pertanyaan "Kenapa [gejala] sendiri?" | Close-up bagian tubuh (mata) di kulit, vinyet gelap | Judul atas 2 baris, kata gejala kuning |
| 3–7 | **Mitos**: "Katanya… X? Y?" | Pil putih bersudut bulat muncul satu-satu (pop) | Pil putih teks hitam: "KATANYA…" + mitos 1, mitos 2 |
| 7–9 | **Bantah**: "Padahal terjadinya di sini" | Mitos dicoret garis merah; kamera zoom ke titik di kulit yang berpendar oranye | Pil dicoret merah |
| 9–16 | **Lapisan 1 – otot** | Menembus kulit ke lapisan otot merah bergelombang; otot bergerak/berkedut | Label berkotak garis kuning + titik penunjuk: NAMA LATIN + deskripsi kecil; pil "TUGASNYA: …" |
| 16–24 | **Lapisan 2 – saraf** | Saraf kuning-zaitun beruas muncul, bercabang, pulsa cahaya | Label "SARAF …"; 3 chip "SINYAL → GERAK → DIAM" menyala bergantian; pil baterai merah "SARAF KELELAHAN" |
| 24–31 | **Mekanisme inti** | Macro serat saraf, percikan cahaya, serat otot ikut bergetar | "KECIL. CEPAT." kuning besar atas; pil "SERAT … IKUT BERKEDUT" |
| 31–34 | **Nama medis** | Kembali ke permukaan kulit | "NAMA MEDISNYA" kecil + istilah emas besar |
| 34–41 | **Pemicu 1–4** | Subjek jadi gelap; ikon 3D mengambang di dalamnya (bulan, awan petir, …, ponsel) | "PEMICUNYA / HAMPIR SELALU SAMA" + angka bulat kuning + nama pemicu |
| 41–47 | **Kabar baik** | Permukaan hangat, titik hijau | Pil hijau "✓ TIDAK BERBAHAYA" + pil kecil "HILANG SENDIRI DALAM BEBERAPA HARI" + 5 titik progres menyala |
| 47–54 | **Waspada** | Subjek redup, lalu kembali ke lapisan merah; penjalaran ke bagian lain ditunjukkan garis + titik merah | "⚠ WASPADA KALAU" merah + 2–3 pil gelap tanda bahaya (kata kunci merah) + label area terkait |
| 54–56 | **Tindakan** | Potongan jaringan bercahaya oranye lalu fade | Pil merah solid "PERIKSA KE DOKTER" |
| 56–60 | **Callback + CTA** | Nuansa malam biru-ungu, mata menutup | Mitos dicoret + "MUNGKIN KAMU CUMA BUTUH TIDUR"; lalu pertanyaan interaktif besar kuning + pil "💬 TULIS DI KOMENTAR" |

## Aturan naskah & VO
- **Rumus hook**: "Kenapa [gejala yang semua orang pernah alami] sendiri?" — gejala harus relatable dan punya mitos populer.
- **Rumus isi**: Mitos (2 butir, bunyi "katanya…") → "Padahal…" → lokasi nyata → pelaku anatomi (otot/saraf/pembuluh) → mekanisme dalam 3 kalimat pendek → nama medis → 4 pemicu → kabar baik → waspada → dokter → callback ke mitos → pertanyaan CTA.
- Panjang: kata ≈ durasi × 2 (±115–125 kata). Kalimat 3–6 kata; satu ide per kalimat; kalimat dipecah agar tiap 1–2 kata jadi satu caption.
- Bahasa: Indonesia santai-sopan, "kamu". Istilah medis Latin selalu diikuti penjelasan awam (label kecil di bawahnya).
- Tutup selalu dengan pertanyaan yang bisa dijawab 1 kata (kiri/kanan, pagi/malam) agar komentar mudah.
- **Larangan**: diagnosis pasti, janji menyembuhkan, nama obat/dosis, menakut-nakuti. Wajib ada batas aman vs waspada + "periksa ke dokter". Fakta medis harus dicek ke sumber terpercaya (Kemenkes, WHO, Mayo/Cleveland Clinic) sebelum render.

Contoh naskah BARU (topik: tangan kesemutan, ±110 kata):
> Kenapa tangan bisa kesemutan sendiri? Katanya, darah kamu kurang. Katanya, ada yang lagi ngomongin. Padahal, masalahnya di sini. Di bawah kulit lengan ada saraf panjang. Tugasnya cuma satu: mengirim sinyal rasa dan gerak. Saat kamu tidur menindih lengan, saraf ini tertekan. Sinyalnya tersendat. Begitu tekanan lepas, saraf kembali menyala, dan muncullah rasa geli itu. Pemicunya hampir selalu sama. Satu, tidur menindih lengan. Dua, duduk menyilang terlalu lama. Tiga, mengetik berjam-jam dengan siku menekuk. Kabar baiknya, ini hampir selalu tidak berbahaya, dan hilang dalam hitungan menit. Tapi waspada kalau sering berulang, lemas saat menggenggam, atau tiba-tiba lemah di satu sisi tubuh. Itu saatnya periksa ke dokter. Kamu biasanya kesemutan di tangan kiri atau kanan?

## Aturan visual
**Palet (perkiraan dari frame referensi)**
| Peran | Hex |
|---|---|
| Latar kulit hangat (atas) | #C98A6E → #8A5444 |
| Vinyet bawah / latar gelap | #1A0F0E → #0B0708 |
| Otot (merah) | #B3202A, highlight #E8554A, bayangan #4A0D14 |
| Saraf | zaitun-emas #B9A94E, glow #FFE9A0 |
| Aksen kuning (kata kunci, nomor, angka) | #FFD84A |
| Hijau AMAN | #3DE08A (teks gelap #0B2A1A) |
| Merah WASPADA/baterai | #FF4D4D / pil solid #E8343F |
| Malam (CTA) | #2B2236 → #7C86E6 (aksen biru-ungu) |
| Teks | putih #FFFFFF, bayangan hitam 60% |

**Tipografi** (Google Font terdekat: **Poppins**): ExtraBold untuk judul/caption, SemiBold untuk label, tracking lebar huruf kapital untuk teks kecil. Semua KAPITAL.
**Ukuran di 1080×1920**: judul atas — kicker 28 px tracking +0.2em, baris utama 130 px (dua tone putih/kuning), maksimal 2 baris, top ±7%. Caption 1–2 kata ±78 px, di y ≈ 63% (±1210 px), bayangan lembut + stroke tipis gelap 2 px. Pil: radius penuh, padding 24×14 px, teks 40 px; label anatomi: kotak gelap 85% opasitas, border kuning 3 px, nama Latin 36 px + deskripsi 24 px, titik penunjuk kuning + garis tipis. Watermark handle kecil 26 px, putih 55%, tengah bawah ±96%. **Pakai handle milik user sendiri.**
**Gaya ilustrasi**: anatomi semi-realistis 3D yang *tenang* — pencahayaan lembut dari atas, depth of field, tekstur serat/gelombang konsentris pada otot, saraf beruas dengan pulsa cahaya. Satu fokus per layar. Ikon pemicu 3D mengilap ("claymorphism" kuning/abu) tanpa meniru ikon emoji merek tertentu — buat sendiri.
**Elemen grafis khas**: pil mitos putih, coretan merah, chip status menyala bergantian, ikon baterai, titik progres 5 buah, badge hijau/merah, garis penunjuk beritik.

## Motion & transisi
- Zoom-in menembus lapisan: 800–1200 ms, ease-in-out cubic, disertai crossfade tekstur (kulit → otot → saraf).
- Pil/label: pop scale 0.85→1.05→1 dalam 250 ms; keluar fade 200 ms.
- Caption: muncul fade+naik 8 px 120 ms, kata kunci berubah putih→kuning sebelum diucap. Beberapa caption fade-out redup sebelum berganti.
- Coretan merah: sapuan kiri-ke-kanan 300 ms.
- Chip SINYAL→GERAK→DIAM: menyala satu-satu mengikuti VO; pulsa cahaya mengalir sepanjang saraf.
- Kamera selalu bergerak pelan (drift ±2%/dtk) agar tak ada frame mati.

## Audio
Musik ambient/lo-fi pelan ±70–80 BPM, −22 dB di bawah VO; whoosh halus tiap zoom lapisan; pop kecil tiap pil; ding naik untuk pil hijau; low-hit hitam untuk "WASPADA"; hening 0,3 dtk sebelum pertanyaan CTA.

## Alur produksi
1. Tentukan topik (gejala relatable + mitos populer). Verifikasi fakta medis lewat sumber resmi; catat sumber di akhir pesan ke user.
2. Tulis naskah dengan rumus di atas; hitung kata ≈ durasi × 2. Pecah jadi caption 1–2 kata + peta waktu (VO per kata).
3. Visual — pilih salah satu:
   a. **Render sendiri**: Remotion/Canvas+ffmpeg 1080×1920. Anatomi dibangun dengan gradien, noise, dan gelombang konsentris (otot), kurva beruas + glow (saraf), kamera zoom antar layer. Semua pil, caption, chip dianimasikan dari timeline kata.
   b. **Paket prompt** untuk tool gambar/video AI (satu prompt per layer: kulit, otot, saraf, macro, ikon pemicu, mata tertutup malam) + panduan susun di CapCut.
4. VO: pakai TTS/rekaman user; sinkronkan caption per kata.
5. Mix audio, ekspor MP4 H.264, buat cover (judul hook + gambar kulit) dan caption posting (hook + 3 hashtag + pertanyaan CTA + disclaimer "edukasi, bukan pengganti dokter").
Output: MP4, naskah, daftar sumber, caption posting.

## Checklist QC
- Hook = pertanyaan relatable, terbaca ≤3 dtk.
- Ada mitos yang dicoret dan dibantah sebelum detik 10.
- Minimal 2 lapisan anatomi + 1 macro; zoom halus tanpa hard cut.
- Caption 1–2 kata, kata kunci kuning, di ±63%, tidak tertutup UI TikTok/Reels (aman 150 px kanan, 250 px bawah).
- Nama Latin selalu punya penjelasan awam.
- Ada pil hijau AMAN **dan** daftar WASPADA **dan** "periksa ke dokter".
- Tidak ada klaim diagnosis/obat/dosis; sumber fakta tercatat.
- Callback mitos di akhir + pertanyaan CTA kiri/kanan.
- Durasi 55–65 dtk; watermark handle user sendiri.
- Palet gelap hangat + merah otot konsisten; tidak ada elemen mirip logo/karakter orang lain.

## Adaptasi Codex / GitHub Actions

Mode V1: paket prompt, naskah, sumber, timeline caption dan petunjuk editing. Belum ada engine Remotion/Canvas dalam paket ini, sehingga jangan mengklaim bisa render MP4. Semua klaim medis dan saran tindakan harus diverifikasi; gejala darurat membutuhkan arahan mencari bantuan medis darurat, bukan hanya kunjungan rutin. Jangan memakai contoh asli sebagai materi klinis yang sudah disahkan. Gunakan API/alat eksternal hanya bila tersedia dan disetujui. Lokasi Codex: `.agents/skills/bedah-medis-mitos-3d/`.
