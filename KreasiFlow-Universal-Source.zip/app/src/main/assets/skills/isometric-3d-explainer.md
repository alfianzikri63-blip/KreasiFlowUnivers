---
name: isometric-3d-explainer
description: Create animated isometric miniature 3D explainers using a Blender procedural renderer for retail, distribution, delivery and receiving processes. Generate a valid episode JSON and animate physical objects rather than camera-only motion.
---
# Isometric 3D Explainer

## Workflow
1. Split narration into discrete process stages. Each scene has a concrete visible action, one supported scene type, and a short narration. Use Indonesian or English.
2. Produce JSON following `episode.schema.json` and `examples/logistics.json`. Do not produce executable code from user text. Supported scene types: retail (stock moves from shelf), warehouse (packages move on a conveyor), delivery (truck drives), receiving (packages move to racks).
3. Run `python3 scripts/render.py --episode examples/logistics.json --output output` from this directory. The renderer uses Blender, FFmpeg, FFprobe and espeak-ng (or espeak). A user may supply a per-scene WAV via `--audio-dir` with filenames `01.wav`, `02.wav`, etc.
4. Read `output/motion_report.json` and `output/video.mp4`. Reject a render if a required moving actor is static, frames are missing or audio/video encoding fails. Do not claim semantic correctness without reviewing the scene against narration.

## Visual contract
Orthographic camera, 45-degree azimuth, roughly 35-degree elevation, industrial miniature sets, colored racks, cardboard parcels, trucks, human figures, soft area lighting. Camera movement must not substitute for subject movement. No random abstract objects. The procedural assets are stylized, not photorealistic reference-image replicas.

## Limits
The v1 engine supports only four built-in logistics scene templates. Arbitrary science, mining, infrastructure or manufacturing topics require additional scene builders and motion templates. An AI planner may create episode JSON, but the renderer does not call an LLM itself. Narration is basic offline TTS by default. The APK requires a matching adapter and workflow registration; importing this package alone does not register executable Blender rendering.
