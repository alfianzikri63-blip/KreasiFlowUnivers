---
name: "bedah-tubuh-klasik"
description: "Video bedah 3D 9:16 ±40 dtk tentang cara kerja tubuh manusia (jantung, paru, cegukan, refleks, bersin…) bergaya bedah-klasik: hook paradoks, \"Kita bedah.\", cutaway organ, HUD angka, caption karaoke."
---

# bedah-tubuh-klasik: bedah biologis tubuh manusia, gaya bedah-klasik

Versi "tubuh manusia" dari **bedah-klasik**. Formatnya sama persis: ±40 dtk, 9:16, bahasa Indonesia santai,
hook paradoks → "Kita bedah." → cutaway 3D yang bergerak mengikuti narasi → angka HUD hidup → tip → reframe.
Tampilannya sama: ruangan abu-abu hangat, garis tinta, judul kiri atas, angka mono besar + sparkline + badge,
caption per kata dengan sorotan kuning, stiker onomatope, SFX. Bedanya hanya pada **subjeknya**: organ dan
sistem tubuh, bukan benda rumah tangga.

Beda dengan skill saudara:
- `bedah-medis-mitos-3d` = bongkar mitos, gelap hangat, 60 dtk, kamera menyelam lapisan kulit.
- `p3k-cutaway-3d` = P3K/pertolongan, stempel JANGAN, kartu langkah.
- **skill ini** = "kok bisa tubuh kita…" — mekanisme tubuh normal, terang, gaya kitabedah.

## 0. Mesin: pakai bedah-klasik

Skill ini **tidak punya scripts/kit sendiri**; ia memakai folder bedah-klasik.

1. Cari foldernya: `.agents/skills/bedah-klasik/SKILL.md` (atau folder skill yang disetujui pengguna; jangan scan seluruh filesystem).
   Sebut folder itu `<klasik>`. Kalau tidak ada, bilang ke user bahwa bedah-klasik harus dipasang dulu.
2. Baca `<klasik>/SKILL.md` dan referensinya (`naskah.md`, `beats.md`, `gaya.md`, `kit-api.md`, `juri.md`,
   `audio.md`). Semua aturan di sana **tetap berlaku**, kecuali yang ditimpa di bawah.
3. Semua perintah sama: `new_episode.py`, `tts.py`, `build.py --words`, `hyperframes check/snapshot/render`,
   `check_video.py` — dijalankan dari `<klasik>/scripts/`. Episode dibuat di `episodes/<nama>/` folder kerja user.
4. Mulai episode baru dari contoh terdekat: `new_episode.py <nama> --contoh kloset` (punya pola state.js
   lengkap), lalu ganti model.js dan state.js dengan tubuh.

Bicara ke user dalam bahasa Indonesia. Gate (berhenti, tunjukkan, tunggu) sama dengan bedah-klasik:
pilih topik, setujui naskah, pilih take suara, cek frame, tonton film.

## 1. Topik: skor 3–5 kandidat

Nilai tiap kandidat 1–5 untuk:
- **Gerak terlihat** — katup menutup, otot meremas, diafragma turun, tulang bergeser, cairan mengalir.
  Gerak mekanis > proses kimia tak terlihat (sama seperti bedah-klasik: mekanisme terlihat menang jauh).
- **Paradoks satu baris** — "Jantungmu nggak pernah cuti. Kok nggak capek?"
- **Semua orang mengalaminya** — cegukan, bersin, merinding, kesemutan, kram, pusing habis muter.
- **Aman dibahas** — bukan penyakit berat, bukan diagnosis, bukan obat.

### 30 ide topik

Jantung & darah: kenapa jantung nggak capek (diastol) · bunyi "lub-dub" itu apa · kenapa nadi bisa diraba
· pembuluh balik di kaki kok bisa naik (katup vena + pompa otot betis) · kenapa luka kecil berhenti berdarah.
Napas: cegukan (diafragma kejang + pita suara menutup "hik") · bersin · batuk · kenapa nggak keselek tiap
menelan (epiglotis) · menguap · napas ditahan kok nggak bisa sampai pingsan.
Gerak: refleks lutut (lengkung refleks, tanpa otak) · kram otot · kenapa kaki kesemutan kalau didudukin
· kenapa jari "kretek" (gelembung gas sendi) · lutut: bantalan meniskus · otot cuma bisa menarik, nggak bisa mendorong.
Indra: kenapa pusing habis muter (cairan kanal setengah lingkaran) · kenapa telinga "budek" di pesawat
(tuba Eustachius) · mata fokus jauh-dekat (lensa) · pupil mengecil di tempat terang · kenapa lidah tergigit.
Kulit & suhu: merinding · keringat mendinginkan · kenapa kulit keriput habis berendam.
Perut: perut keroncongan · makanan nggak jatuh walau jungkir balik (peristaltik) · cegukan vs sendawa · ngantuk habis makan.
Lain: kenapa rambut putih · kenapa kuku tumbuh terus · tulang patah kok bisa nyambung sendiri.

*Gate: user memilih.*

## 2. Fakta dulu (`episode/fakta.md`)

Setiap angka dan klaim diberi tingkat sumber:
- **resmi** — buku teks fisiologi/anatomi (Guyton & Hall, Gray's), StatPearls/NCBI Bookshelf, WHO,
  Kemenkes, jurnal peer-review, situs organisasi profesi (AHA, dll.).
- **media** — artikel kesehatan populer yang mengutip sumber resmi.
- **dimodelkan** — dibesar-besarkan untuk animasi (gerak katup 3×, kecepatan aliran diperlambat). Tidak
  pernah diucapkan sebagai fakta.

Aturan khusus tubuh:
- Angka fisiologi selalu berupa **rentang orang dewasa sehat saat istirahat** ("60–100 per menit"),
  dengan kata "kira-kira" kalau sumbernya memberi perkiraan.
- Tulis juga nama ilmiah tiap bagian (untuk label) + nama awamnya (untuk VO).
- Riset bisa mengubah punchline. Contoh: "jantung nggak pernah istirahat" ternyata salah — ia istirahat
  di fase diastol tiap detak. Itu justru jadi reframe-nya.

## 3. Naskah

Ikuti `<klasik>/references/naskah.md` (10 beat, 95–130 kata, kalimat 2–8 kata, tanpa jeda mati,
`{tulisan|ucapan}`). Tambahan untuk tubuh:

| Beat | Versi tubuh |
|---|---|
| 1 Hook | Bunyi tubuh sebagai kata pertama bekerja bagus: "Dug-dug.", "Hik!", "Hachi!", "Kretek." Sebut organnya dalam 3 kata pertama. |
| 2 Paradoks | Pengalaman sehari-hari + angka di layar dari detik 1 (bpm, kali/hari, liter/menit). |
| 3 "Kita bedah." | Kulit manekin terbuka / jadi tembus pandang pada kata ini. |
| 4–7 Mekanisme | Satu aksi per kalimat; nama awam dulu, istilah ilmiah di label ("katup — namanya katup mitral"). Satu open loop ±12 dtk. |
| 9 Tip | **Tip aman dan umum** yang bisa dicek hari ini (cek nadi istirahat pagi, tahan napas + minum untuk cegukan *sebagai trik populer, bukan terapi*), plus kapan ke dokter kalau relevan ("kalau cegukan lebih dari 2 hari, periksa ke dokter"). Tidak ada dosis obat, tidak ada diagnosis. |
| 10 Reframe | Dua kalimat menjawab hook: "Jadi jantung bukan nggak pernah istirahat. Dia istirahat di setiap detak." |

Bahasa: "kamu/-mu", santai Jakarta. Hindari kata yang menakut-nakuti ("bahaya!", "mematikan") kecuali
memang faktanya dan bersumber resmi.

*Gate: user menyetujui naskah.*

## 4. Membangun tubuh (model.js + state.js)

Aturan inti bedah-klasik tetap: **mekanisme yang benar, proporsi nyata, bentuk boleh disederhanakan,
mekanismenya tidak**. Penonton tidak pernah membuka jantungnya sendiri, tapi pernah lihat gambar di buku
biologi SMA — jadi orientasi, jumlah ruang, posisi katup, arah aliran harus sesuai buku teks.

### 4a. Manekin pembuka (konteks)

Hook dibuka pada **manekin netral** di ruangan abu-abu bedah-klasik, lalu kamera menyelam ke organ.
- Dibangun dari kit: torso `K.lathe`, kepala `K.sphere`, lengan/kaki `K.cyl` atau `K.tube` tebal, sendi bola kecil.
- Warna abu-hangat polos `0xcfc8bf`, `hull: true` + tinta. **Bukan warna kulit** (netral untuk semua penonton).
- Tanpa wajah detail, tanpa puting, tanpa alat kelamin, tanpa rambut — gaya manekin toko/boneka kayu.
- Pose santai, berdiri atau duduk sesuai cerita (duduk untuk refleks lutut).
- Organ yang dibahas sudah ada di dalamnya pada skala benar, ditandai **jendela potong**: pada "Kita bedah."
  separuh depan cangkang torso memudar (`K.setOpacity`) dan menyisakan tepi potong ber-hatch (`cutBox`
  atau `latheSection` dengan tutup potongan), lalu kamera masuk.

### 4b. Skala

- Adegan manekin: 1 unit = 10 cm (sama dengan bedah-klasik).
- Adegan organ close-up: 1 unit = 1 cm, `K.room({ scale })`, `near`/`far` di beats.json
  (pola "tiny objects" dari pentil-ban). Pindah skala dengan potongan kamera, bukan di tengah gerakan.

### 4c. Palet anatomi (warna kalem, saturasi hanya pada cerita)

Warna dasar organ **diredam** supaya `K.KODE` tetap jadi penanda cerita:

| Bagian | Warna dasar |
|---|---|
| Otot / dinding jantung | merah bata redam `0xb9675c` |
| Rongga / bagian dalam organ (dinding potong) | `0x8e4b45` dengan hatch |
| Tulang | gading `0xe8e0cf` |
| Tulang rawan, meniskus | biru-abu pucat `0xc9d6da` |
| Lemak | krem `0xeed9a8` |
| Paru | merah muda pucat `0xd9a3a0` |
| Saraf | krem-kuning pucat `0xe6d8a8` (bukan kuning fokus) |
| Darah kaya oksigen | `K.KODE.panas` (merah) |
| Darah miskin oksigen | `K.KODE.magnet` (biru) — konvensi buku teks |
| Udara | titik putih/biru muda transparan |

Kode cerita tetap dari bedah-klasik: **kuning = bagian yang sedang disebut** (sorot saat narator
menyebutnya), hijau = normal/aman, oranye = lebih dari biasanya (detak naik, suhu naik), merah = alarm.
Sinyal saraf/listrik: pulsa kuning-putih berjalan di sepanjang `K.tube` saraf (dipicu dari state.js).

### 4d. Organ: cara membangun

- **Potongan frontal 2,5D** dulu (paling terbaca, mirip gambar buku): `K.extrude` siluet organ, rongga-rongga
  di-extrude warna gelap sedikit di depan (z +0.01), tepi potong ber-hatch. Jantung 4 ruang, paru, lambung,
  ginjal, mata, telinga dalam semua bisa begini.
- Organ bulat/pipa: `K.lathe` (bola mata, kandung kemih, pembuluh), `K.tube` (pembuluh, saraf, usus, trakea),
  `K.sphere` diskalakan (lobus, alveolus).
- **Katup** = `hinge(K, pos)` + daun tipis `K.extrude`; `.swing(rad)` dari state.js.
- Otot meremas = skala/morf tertutup dari state (mis. `scale.x = 1 - 0.12*kontraksi(t)`), pivot di
  tempat menempelnya; tendon tetap.
- Aliran darah/udara: `K.flowLine` + titik ber-instance (seed `hash`), **bukan hanya garis putus-putus**.
- Bentuk organik rumit (otak, tengkorak, hati utuh): Blender → GLB, decimate dulu sebelum tinta (EdgesGeometry
  pada mesh rapat = noise), restyle dengan `K.mat` + hull. Sumber mesh anatomi terbuka: BodyParts3D,
  Z-Anatomy, NIH 3D — **cek lisensinya** (banyak CC BY-SA) dan cantumkan kredit di caption.
- Detail "buatan manusia": label nama ilmiah kecil dengan `K.decal` di dekat bagian ("VALVA MITRALIS"),
  serat otot sebagai garis halus, cincin tulang rawan trakea, cabang pembuluh. Semua sederhana tapi benar.

### 4e. state.js: tubuh sebagai fungsi waktu

Sama seperti kloset: fungsi murni dari `t`, dijangkarkan ke `data.marks`. HUD dan gerak membaca fungsi
yang sama, jadi angka dan gambar selalu cocok. Satuan HUD yang cocok:
`bpm` (detak), `mmHg` (tekanan), `ml` / `L/mnt` (volume, curah), `°C` (suhu), `%` (saturasi O₂, fase siklus),
`m/dtk` (kecepatan sinyal saraf), `kali/mnt` (napas). Badge status: `NORMAL` hijau, `NAIK` oranye, `ISTIRAHAT` biru.

Siklus berulang (detak, napas) = fungsi periodik tertutup (`(t - mark) % periode`), jangan diakumulasi per frame.
Gerak kecil dibesar-besarkan (katup, gelembung sendi) dan ditandai *dimodelkan*. Pakai `GERAK LAMBAT 4×` di
badge saat memperlambat siklus nyata.

### 4f. Lihat dan cek (gate)

Snapshot di momen kunci, crop 4× setiap sambungan: katup menempel di cincinnya, pembuluh masuk ke organ
(bukan melayang), arah aliran benar (atrium → ventrikel → arteri), kiri-kanan tubuh benar (**kiri tubuh
manekin = kanan layar** saat menghadap kamera — label "KIRI/KANAN" ikut tubuh, bukan layar).

## 5. Suara, beats, build, juri, render, posting

Sama dengan bedah-klasik tahap 5–10. Tambahan:

**Stiker onomatope tubuh:** DUG! · LUB! · DUB! · HIK! · HACHI! · KRETEK! · GLEK! · KRUUK! · HAP! —
hanya pada bunyi atau reveal; jangan menutupi organ pada momen kuncinya.

**SFX:** detak jantung lembut (low thump) tepat pada "lub"/"dub", whoosh pada masuk ke tubuh, pop kecil
untuk label, gelembung/aliran halus untuk darah. Sumber dan lisensi mengikuti `<klasik>/references/audio.md`.

**Juri** (`<klasik>/references/juri.md`) + 3 butir tambahan, nilai terendah tetap menentukan:

| Butir | 10 terlihat seperti |
|---|---|
| Akurasi anatomi | Jumlah/posisi ruang, katup, arah aliran, kiri-kanan cocok dengan buku teks; nama ilmiah benar. |
| Aman & sopan | Tidak ada darah muncrat, luka, atau gore; manekin netral tanpa detail tubuh pribadi; tidak menakut-nakuti. |
| Klaim medis | Setiap angka/klaim ada di fakta.md tingkat resmi; tip umum dan aman; tidak ada diagnosis/dosis. |

Berikan juri (subagen segar) hanya frame, naskah, fakta.md, dan rubrik. Render hanya kalau ≥ 8.

**Posting:** cover menjawab "ini soal apa?" ("Kenapa jantung nggak capek?"), caption dengan sumber resmi,
kredit aset (mesh CC BY/BY-SA, musik), 3–5 hashtag (#bedahtubuh #faktatubuh #belajardisosmed …), satu baris
**"Konten edukasi umum, bukan pengganti konsultasi dokter."**, dan ingatkan label suara AI sesuai aturan platform.

## 6. Contoh kerja: "Kok jantung nggak pernah capek?"

**Mekanisme (resmi, Guyton/StatPearls):** nodus SA memicu sinyal → atrium kontraksi → katup
trikuspid & mitral menutup ("lub") → ventrikel kontraksi, darah ke aorta & arteri pulmonalis → katup
semilunar menutup ("dub") → diastol: otot rileks, ruang terisi lagi. Pada ±75 bpm satu siklus ±0,8 dtk,
diastol kira-kira dua pertiganya. Detak istirahat dewasa normal 60–100 bpm; ±100 ribu detak per hari.
(Verifikasi tiap angka saat menulis fakta.md.)

**Naskah (±115 kata):**
```
Dug-dug. Jantungmu udah berdetak sejak sebelum kamu lahir.
{±100 ribu|seratus ribu} kali sehari. Nggak pernah cuti. Kok nggak capek?
Kita bedah.
Di dinding atas ada simpul kecil. {Nodus SA|nodus es-a}. Pemicu listrik alami.
Sinyalnya nyebar. Serambi meremas. Darah turun ke bilik.
Lalu katupnya nutup. Itu bunyi lub.
Bilik meremas keras. Darah keluar ke seluruh tubuh.
Katup kedua nutup. Itu dub.
Tapi ada satu bagian yang aneh.
Habis dub, ototnya rileks total.
Dari tiap detak, kira-kira dua pertiganya istirahat.
Coba cek nadimu pagi hari, sebelum bangun.
Normalnya {60–100|enam puluh sampai seratus} per menit.
Jadi jantung bukan nggak pernah istirahat.
Dia istirahat di setiap detak.
```

**Rencana visual:** manekin berdiri, HUD `72 bpm` + sparkline EKG, badge NORMAL → "Kita bedah": dada
memudar, kamera menyelam ke jantung potongan frontal 4 ruang → nodus SA menyala kuning, pulsa menjalar
→ atrium mengecil, titik darah turun → daun katup AV berayun tutup + stiker LUB! → ventrikel meremas,
titik merah ke aorta, biru ke arteri pulmonalis → katup semilunar tutup + DUB! → otot kembali ke warna
redam, badge berubah ISTIRAHAT biru, kartu "0,8 dtk = kerja ⅓ + istirahat ⅔" (bar dua warna) → tarik keluar
ke pergelangan manekin, titik nadi berdenyut → final: jantung di tengah band, berdetak pelan.

**state.js (pola):** `fase(t) = ((t - m.mulai) % 0.8) / 0.8`; `atrium = pulse(fase, 0.00, 0.12)`,
`ventrikel = pulse(fase, 0.15, 0.40)`, `katupAV = fase > 0.13 && fase < 0.42 ? tutup : buka`,
`hud = { value: 72, status: fase < 0.42 ? 'KERJA' : 'ISTIRAHAT', … }`. Siklus diperlambat 4× di beat
mekanisme (badge GERAK LAMBAT 4×), kecepatan normal di hook dan penutup.

## Revisi

Sama dengan bedah-klasik: "detik 12 kurang pas" → petakan ke beat (`build.py --words`), ubah beats.json /
state.js / model.js, build ulang, snapshot rentang itu, tunjukkan. Jangan pernah edit HTML hasil build.

Setiap kali juri atau user menangkap masalah khas tubuh (kiri-kanan terbalik, katup melayang, warna organ
terlalu mencolok), catat aturannya di bagian "Known traps" baru di episode `fakta.md` dan usulkan ke user
untuk ditambahkan ke skill ini.

## Adaptasi Codex / GitHub Actions

Dependensi: Bedah_Klasik_Codex_V1.zip. Ekstrak kedua ZIP ke `.agents/skills/` dalam workspace yang sama. Gunakan `episodes/<slug>/` seperti Bedah Klasik, buat model.js/state.js dan beats.json baru yang akurat, dan jalankan workflow `render.yml` mode custom dengan slug episode. Contoh jantung di dokumen merupakan rencana/naskah, bukan model render siap pakai atau fakta medis terverifikasi. Tidak ada demo MP4 organ bawaan. Periksa sumber anatomi, proporsi, orientasi, hak aset, dan klaim sebelum render/publikasi.
