---
name: psych-parable
description: "Video explainer psikologi 9:16 berbahasa Indonesia (60–80 dtk) bergaya \"perumpamaan sinematik\": satu cerita/fabel pendek dengan karakter siluet hitam beraksesoris warna di latar flat-vector bercahaya hangat, lalu \"Dalam psikologi, ini dikenal sebagai …\", data penelitian, contoh hidup modern, dan pertanyaan reflektif ke penonton. Juga format pendek tanpa narasi (±15 dtk, satu perbandingan data). Use when the user wants a psychology / behavioural-science / finance-habit explainer Reel like @overthinkclub.id, \"video psikologi\", \"kenapa kita …\", \"efek …\", or when video-clone routes a reference with this look here."
---

# psych-parable — perumpamaan psikologi sinematik

> **Referensi visual siap pakai: `reference/REFERENCE.md`** — template 1080×1920 untuk hook, kartu psikologi, kartu data,
> chat, adegan kamar, end card, aturan caption & area aman, dan pustaka pose (`reference/templates/png/`), plus lembar
> karakter. Lihat template ketukan yang sedang dibuat sebelum menyusun frame.

Diturunkan dari analisa 4 referensi (`reference/STYLE.md`: pengukuran, rumus naskah dari transkrip, momen puncak).
Skill ini menentukan **naskah, desain, dan bahasa kamera**; pembuatan frame-nya lewat engine `hyperframes`
(muat `/hyperframes` lalu ikuti alurnya), dengan aturan di bawah sebagai design system.

> Pelajari gayanya, jangan menyalin merek. Watermark, handle, dan end card memakai akun pengguna sendiri
> (tanya kalau belum ada), bukan "@overthinkclub.id". Cerita, karakter, dan ilustrasi dibuat baru.

## 1. Naskah (wajib ikut 9 ketukan ini)

Target 170–190 kata untuk 70 dtk (±2,5 kata/dtk). Kalimat pendek, sapaan "kita/kamu", banyak koma untuk jeda.

| # | Ketukan | Waktu (70 dtk) | Rumus kalimat |
|---|---|---|---|
| 1 | Paradoks pembuka | 0–8 | "[Subjek] [melakukan hal wajar]. [Waktu] kemudian, [hasil yang berlawanan]." |
| 2 | Cerita, eskalasi 3 langkah | 8–22 | Tiga langkah yang makin besar/kecil, dialog dalam kutip, pola diulang ("Hidung. Boleh. Kepala. Boleh. Kaki. Ya sudah.") |
| 3 | Kalimat kunci | 20–26 | Satu kalimat yang merangkum ironi ("Unta itu tidak pernah minta tendanya. Cuma… 'sedikit lagi.'") |
| 4 | Twist | 26–35 | "Dan bagian paling aneh/ngeri, …" — fakta baru yang membalik cerita |
| 5 | Istilah | 35–45 | "Dalam psikologi, ini dikenal sebagai **[ISTILAH]**." + definisi satu kalimat |
| 6 | Bukti (opsional) | 42–50 | "Ada penelitiannya. [Kondisi A], cuma X%. [Kondisi B], Y%." — angka asli + sitasi |
| 7 | Cermin | 50–60 | "Dan kita juga begitu." + 2–3 contoh hidup modern, paralel ("Dulu … karena … Sekarang …") |
| 8 | Aforisme | 60–65 | "Jadi ingat ini, …" memakai metafora cerita ("tidak ada unta yang langsung minta seluruh tenda") |
| 9 | Pertanyaan | 65–72 | Pertanyaan pribadi ke penonton memakai metafora yang sama ("Jujur, siapa 'unta' di hidupmu?") — jadi end card |

Judul hook di layar (ketukan 1) berbentuk pertanyaan: label kecil "KENAPA KITA …" + isi besar
("SUSAH BILANG 'TIDAK'?"). Narasi tidak membaca judul, langsung masuk cerita.

**Fakta harus benar.** Istilah, angka, dan sitasi (penulis, tahun, jurnal) diverifikasi sebelum dipakai;
kalau ragu, buang ketukan 6 daripada mengarang angka.

Format pendek (tanpa narasi, 12–20 dtk): satu perbandingan data yang dianimasikan (mis. dua karakter, dua toples
yang terisi seiring umur), headline 2 baris yang menumpuk satu per satu, angka count-up, catatan asumsi kecil di bawah.

## 2. Design system

Ukuran 1080×1920, 30 fps. Area aman: teks utama di 8–22% (atas) dan 76–84% (caption), hindari 88–100% (UI Reels).

**Warna**
- Malam/kartu: `--navy-900 #0E1430`, `--navy-800 #131A3A`, `--navy-700 #1B2350`
- Aksen judul & kata kunci: `--amber #F2B544` (bayangan `0 2px 12px rgba(0,0,0,.45)`)
- Teks: putih `#FFFFFF`, label `rgba(255,255,255,.8)`, sitasi `#7A86A8`
- Siluet karakter: `#0E0E11` (bukan hitam murni; terukur #0D0E10–#110F10) dengan rim light hangat 1–2 px `#FFD9A0` 60%
- Aksesoris, dua tone cel-shading (terang / bayangan), sampel piksel dari referensi:
  mint kupluk `#81E1BD / #63B092`, biru jaket `#67B5DC / #55819B`, salmon jaket `#F58373 / #D67161`,
  ungu tas `#B6A5FA / #988ACD`, kuning kerah/helm `#F2C15D / #CDAA44`, syal indigo `#5F5FB4`, kardigan marun pudar `#944F50 / #7A3E40`
- Palet mood per babak: navy malam (ragu) → senja oranye-ungu `#A17763/#E2B377/#39285E` (cerita hangat)
  → abu kabut `#AEBAC2` (antiklimaks) → biru pagi / senja baru (resolusi)

**Tipografi** (Google Fonts)
- Judul & istilah: `Bebas Neue` (atau `Anton`), kapital, amber, 2–3 baris rata tengah, line-height 0,95
- Label di atas judul: `Barlow Condensed` 600, kapital, letter-spacing .15em, putih 80%
- Caption: `Plus Jakarta Sans` 800, putih, satu kata kunci amber per potongan
- Sitasi/catatan: `Plus Jakarta Sans` 500, 18–22 px, `#7A86A8`

**Karakter: "stickman gemuk" siluet** — pakai `assets/silhouette_rig.js` (bukan `vector_rig`, yang berkulit, ber-outline,
dan berwajah gelap). Rig ini sudah dicocokkan berdampingan dengan referensi; lembar karakter + perbandingan ada di
`reference/charsheet/` (`sheet.png`). API: `SRig.make(svg, { d, acc }).pose({ x, y, expr, armL, armR, legL, legR, lean, head, look, legScale, breath, blink, prop, light })`.
Contoh adegan HyperFrames yang sudah lolos lint + `motion_check`: `examples/rig-test/build/index.html` (jalan, menoleh,
ganti ekspresi, caption, push-in). Pelajaran dari uji itu:
- Pose dihitung dari waktu di satu `onUpdate` (fungsi murni `draw(t)`); napas = sinus, kedip = daftar waktu tetap, tanpa `Math.random`.
- Karakter yang berhenti **wajib** tetap hidup: `breath`, `blink`, plus satu aksi sekunder (melirik, kepala menunduk,
  bahu merosot) setiap ±1 dtk. Napas + kedip saja masih terdeteksi "freeze" oleh `motion_check.py`.
- Menoleh = geser `look` selama ±0,25 dtk; `facing` (arah lampu/kaki) ikut berbalik saat `look` melewati 0.
- **Tanah miring & melangkah**: beri `slope` (dy/dx layar, mis. -0,32 = naik ke kanan) → kaki pakai IK, telapak menapak
  di garis tanah dan miring mengikutinya; kaki sisi tanjakan otomatis menekuk. Untuk jalan, gabungkan
  `SRig.gait(jarakTempuhPx, { d, amp, facing, stride, lift })` ke pose: telapak yang menapak diam di dunia (tidak
  meluncur), kaki ayun terangkat, pinggul turun saat dua kaki menapak, lengan berayun berlawanan, pinggul menyempit
  supaya kaki tidak bersilang. `amp` 1→0 untuk melambat sampai berhenti. Tanah datar = `slope: 0`.
- Cek langkah dengan crop area kaki 12 fps (bukan strip penuh — terlalu kecil untuk melihat lutut terbalik/telapak melayang).
- **Sinkron ke narasi**: ukur awal tiap frasa dari jeda hening (`ffmpeg -af silencedetect=n=-40dB:d=0.2`), bukan dari
  timestamp kata Whisper (batas katanya meleset ±0,3 dtk). Simpan sebagai tabel cue `N = { s1, s2, … }` di composition
  dan turunkan semua waktu (caption, menoleh, ganti ekspresi, kamera) dari situ — ganti suara cukup ubah tabelnya.
  Caption muncul 0,05 dtk sebelum frasanya dan bertahan selama jeda sampai frasa berikutnya.
- Durasi composition = durasi narasi + ±1 dtk ekor. Narasi dinormalkan ke ±-16 LUFS; musik ambient ±15 dB di bawahnya.
  Tanpa musik berlisensi, pad malam bisa disintesis: beberapa `sine` (A2, E3, A3, C4) + `tremolo` lambat + `aecho` +
  fade, `loudnorm=I=-28` (contoh lengkap di `examples/rig-test`, file `build/assets/musik.wav`).
- **Jeda narasi wajib diisi aksi bermakna** (mengusap keringat, mendongak ke puncak, sorot lampu menyapu teman), plus
  kabut melayang dan push-in kamera yang terus bergerak (easing `none`, bukan `sine.inOut` yang melambat di ujung).
  Ukuran: `motion_check` menandai < 0,0015 rata-rata beda frame; jalan ±0,0027, berdiri + napas saja ±0,0007.
- Selalu transkrip ulang hasil TTS sebelum sinkron: TTS bisa salah ucap (uji ini: "Lima sahabat" terdengar "Sobat lama").
- Lingkup `<svg>` rig: host `<g>` boleh dipakai asal `querySelector` diarahkan ke `<svg>` induk (lihat `hostFor` di contoh).

Proporsi terukur (satuan d = diameter kepala; referensi d ≈ 95 px pada frame 720 px, total tinggi ≈ 3,6 d):

| bagian | ukuran | catatan |
|---|---|---|
| Kepala | lingkaran sempurna, d | bentuk paling dominan |
| Leher | pendek ±0,1 d | lengkung halus dari bawah kepala ke bahu (bidak catur), tidak bersudut |
| Badan | tinggi 1,1 d, lebar ±0,8 d | **lebih sempit dari kepala**, persegi panjang membulat, bahu tegas (bukan melebar ke bawah) |
| Lengan | tebal 0,15 d, panjang ±1,0 d, tangan bulat r 0,09 d | menggantung hampir lurus di sisi badan, ujung sampai pinggul |
| Kaki | tebal 0,16 d, panjang 1,3 d, jarak antar kaki 0,4 d | lurus, tanpa lutut kecuali saat berlari/memanjat |
| Telapak | bulatan kecil 0,26 d × 0,16 d | sedikit mengarah ke luar |

- **Wajah** (putih `#FFFFFF`, garis 0,04 d, posisi di 45–60% tinggi kepala):
  normal = dua titik oval 0,08 d + senyum lengkung lebar 0,3 d · senang = mata "^^" lengkung · capek/ngantuk = kelopak
  setengah garis datar + mulut "o" kecil · sedih/ragu = alis miring + mulut cemberut · cemas = alis naik + mulut
  bergelombang + tetes keringat biru `#9FD8F0` · kaget = mata lingkaran besar dengan pupil kecil · kesal = mata ">  <".
  Tidak ada hidung, telinga, atau rambut (kecuali tokoh tua: dua jumput rambut putih di samping + kacamata bulat).
- **Identitas = satu aksesoris warna** di badan/kepala (kupluk, jaket/kardigan yang menutup badan, tas punggung,
  kerah/syal, helm), dengan cel-shading dua tone dan sisi terang menghadap sumber cahaya. Benda ikonik kedua boleh:
  headlamp (titik putih-kuning + glow + sorot kerucut transparan), HP yang menyala ke wajah.
- **Cahaya**: siluet sendiri tidak di-shade; hanya rim light hangat di sisi yang menghadap lampu. Saat close-up,
  latar diblur dan rim light dipertebal.
- **Gerak**: berjalan dengan kaki lurus mengayun (seperti gunting), badan sedikit naik-turun; idle = napas kecil
  (skala badan 1–2%) + kedip. Ekspresi berganti dengan pop cepat (2–3 frame), bukan morph lambat.
- **Hewan & tokoh lain** memakai bahasa yang sama: siluet `#0E0E11` + mata/mulut putih (unta: kepala lonjong,
  leher panjang, punuk berselimut kuning bercorak).
- **Varian terang** (format pendek): badan putih `#F1F3EF` (bayangan `#E6E7EA`) bercahaya lembut di atas latar hitam
  `#060808`, wajah garis hitam, syal warna (biru `#6ED4FC` vs oranye `#FCB067`) untuk membedakan dua tokoh.

**Latar**
- Flat vector berlapis 3–5 layer parallax, gradasi lembut, grain 3–4%, vignette, bloom pada sumber cahaya
  (jendela, lentera, lampu jalan, matahari).
- Satu sumber cahaya hangat utama per adegan; karakter diletakkan di dekatnya.
- Detail lokal Indonesia (gang, ember, papan pos, warung) dibuat sederhana.
- Watermark handle pengguna kecil, opasitas 15%, ditempel di benda di dalam adegan.

## 3. Komponen layar

1. **Hook card**: label + judul amber di atas adegan pembuka yang sudah bergerak; muncul 0,3 dtk, bertahan 4–7 dtk,
   keluar dengan fade + sedikit naik.
2. **Caption narasi**: potongan 2–3 kata, muncul abu → putih dalam 0,1 dtk, kata kunci amber, ganti setiap
   0,4–0,9 dtk sesuai timestamp narasi (pakai word timing dari TTS/transkrip).
3. **Kartu "DALAM PSIKOLOGI"**: navy polos, label kecil → istilah amber 2 baris → ikon garis putih tipis (stroke 2–3 px)
   dengan satu elemen amber yang beranimasi (hati menyala, pintu terbuka, tangga naik, kepala dengan thought bubble)
   → definisi putih → sitasi kecil di bawah.
4. **Kartu "ADA PENELITIANNYA"**: dua kolom, label kecil per kolom, ikon garis, angka besar count-up (yang menang amber),
   bar progres tipis, keterangan kondisi kecil, sitasi lengkap.
5. **UI dalam dunia**: chat grup, notifikasi HP, counter like — flat, sudut membulat, warna bubble = warna aksesoris
   karakter pengirim.
6. **Balon komik** untuk satu kata ledakan di puncak ("TIDAK"): starburst putih outline hitam, teks condensed hitam.
7. **End card**: label kecil ("JUJUR…", "KAPAN TERAKHIR KALI…") + pertanyaan amber 2–3 baris + handle + "Sumber: …",
   di atas adegan callback yang pelan menjauh.

## 4. Kamera & editing

- Default setiap shot: slow push-in 2–4% + drift horizontal kecil. Shot diam hanya untuk kartu data/teks
  atau satu "freeze" emosional. Target 85–95% shot bergerak.
- Rata-rata shot 3,5–5 dtk. Satu **montase cepat** (3–5 shot × 0,6–0,9 dtk: close-up kaki gemetar, wajah, kalender
  berganti) tepat sebelum puncak; perubahan ritme ini yang menandai klimaks.
- Close-up besar karakter (memenuhi 60% frame, latar blur) untuk momen sadar/twist.
- Split-screen/panel grid untuk "semua merasakan hal yang sama".
- Transisi: cut lurus atau dissolve 0,3–0,5 dtk. Pindah ke kartu navy lewat adegan malam (match warna) atau
  "fade to navy". Tidak ada flash putih, tidak ada whip/glitch.
- Babak terakhir kembali ke lokasi pembuka dengan cahaya baru (callback).

## 5. Audio

- Narasi manusia/TTS Bahasa Indonesia, tenang, hangat, sedikit bercerita (ElevenLabs bila ada key; jika tidak,
  TTS yang tersedia lewat `/media-use`). Dialog karakter dibaca narator dengan nada sedikit berbeda.
- Musik ambient/lo-fi piano 110–130 BPM di -22 LUFS di bawah narasi; naik pelan sebelum puncak, turun saat kartu
  psikologi, resolusi hangat di akhir.
- SFX halus dan realistis (angin, langkah, notifikasi, koin). Tanpa efek kartun.

## 6. Checklist sebelum render final

- [ ] 9 ketukan naskah ada dan urut; pertanyaan akhir memakai metafora cerita
- [ ] Istilah, angka, dan sitasi sudah diverifikasi
- [ ] Setiap karakter siluet hitam + satu aksesoris warna, konsisten di semua shot
- [ ] Caption sinkron per kata, kata kunci amber, tidak menabrak UI Reels
- [ ] ≥85% shot bergerak; ada satu montase cepat sebelum puncak; ada close-up twist
- [ ] Kartu psikologi navy dengan ikon garis beranimasi; end card berisi pertanyaan + handle pengguna + sumber
- [ ] Bandingkan tiap frame kunci berdampingan dengan template ketukannya di `reference/templates/png/` (komposisi, area aman, ukuran teks)

## Adaptasi Codex / GitHub Actions

Gunakan Codex dengan skill ini, tanpa perintah slash Claude `/hyperframes` atau `/media-use`. Untuk render, gunakan HyperFrames versi yang dipin di workflow `render-psych.yml` dan FFmpeg; untuk VO gunakan rekaman pengguna atau Edge TTS (cek timing frasa nyata; jangan mengarang timing). Contoh yang disertakan adalah rig-test 12,4 detik, bukan episode 70 detik. Untuk episode baru, buat `psych-episodes/<slug>/index.html` dengan assets/fonts dan audio lokal yang lengkap, sesuai contoh; periksa komposisi, timeline dan hak aset. Pilih mode custom pada workflow. Gunakan handle sendiri. Jangan gunakan angka penelitian yang belum diverifikasi. Jangan memublikasikan contoh dengan placeholder watermark.
