# Writing the script

## Shape: 10 beats, about 40 s, 95–130 words

| # | Beat | Time | Notes |
|---|---|---|---|
| 1 | Hook | 0–2 s | Name the object in the first 3 words, say the contradiction. Onomatopoeia ("Byur!", "Klik!") works as the very first word. |
| 2 | Ordinary use + paradox | 2–8 s | "Nggak pakai listrik, nggak pakai sensor. Kok tahu udah penuh?" A number on screen from the first second. |
| 3 | "Kita bedah." | ~8 s | The catchphrase; the cutaway opens on these words. |
| 4–7 | Mechanism, 3–5 steps | 9–30 s | One action per sentence. Name each part as it is shown. One open loop around 12 s helps ("tapi ada satu bagian yang aneh…"). |
| 8 | The number | inside 4–7 | One calculation or comparison (1250 W ÷ 220 V ≈ 5,7 A; lengan 10× lebih panjang). |
| 9 | Practical tip | 30–37 s | Something the viewer can do today (cek bocor, cek 3 pengaman). |
| 10 | Reframe | last 3–4 s | Two short sentences that answer the hook: "Jadi itu bukan sensor. Itu pelampung." |

## Language

- Casual Jakarta Indonesian: nggak, udah, kok, kayak, ngisi. No textbook phrasing.
- Sentences of 2–8 words. Each technical term explained in the same breath ("bimetal: dua logam yang direkatkan").
- No dead air: every sentence starts a new visual. If a sentence has nothing to show, cut it.
- Numbers: write them for the screen, spell them for the narrator:
  `{103 °C|seratus tiga derajat}`, `{1:10|satu banding sepuluh}`, `{magic com|mejikom}`.
  Plain words need no braces.
- Every number comes from fakta.md; modelled numbers (dimodelkan) are never stated as fact.

## Checks before the gate

- Read it aloud at speed: does it fit 35–45 s? (tts.py prints the length.)
- Does the last line answer the first?
- Could a viewer repeat the mechanism to a friend in one sentence afterwards?
