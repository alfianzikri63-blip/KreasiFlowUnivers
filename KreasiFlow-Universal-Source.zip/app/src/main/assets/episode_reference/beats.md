# beats.json

Every time is an anchor to a spoken word, so a new take re-times the whole film.

## Anchors

| Form | Means |
|---|---|
| `"bedah"` | start of the first "bedah" (case and punctuation ignored) |
| `"karet#2"` | start of the second "karet" |
| `"lipat>"` | end of "lipat" |
| `"bedah+0.3"`, `"Air#2-0.1"` | offset in seconds |
| `"@12.5"` | absolute time |
| `"end"` | end of the film |

Case is ignored, so "Air" and "air" are the same word: always check with
`python -I <skill>/scripts/build.py <ep> --words`, which prints each word with its `word#n`.
build.py refuses titles out of order and windows that end before they start.

## Fields

```jsonc
{
  "tail": 1.2,            // seconds after the last word
  "zoom": 1.6, "fov": 28, "viewOffsetY": 150, "pixelRatio": 2,
  "hud": { "unit": "liter", "decimals": 1, "min": 0, "max": 6 },
  "marks": { "flush": "Byur", "cut": "Kita+0.08" },          // -> data.marks in state.js
  "judul": [{ "at": "@0", "text": "Kok tangki kloset tahu kapan *penuh*?" }],   // *word* = red; runs until the next
  "badge": [{ "at": "@1.2", "until": "@3.05", "text": "GERAK CEPAT 4×" }],
  "stiker": [{ "at": "Byur", "text": "BYUR!", "color": "biru|merah|hijau", "y": 640, "dur": 1.3, "size": 112 }],
  "kartu": [{ "at": "Lengannya", "until": "Pas", "y": 840, "html": "<div class=\"bd-card-h\">…</div>" }],
  "label": [{ "text": "PELAMPUNG", "side": "L|R", "anchor": "ball", "wins": [["pelampung", "Karet#2"]] }],
  "kamera": [{ "at": "Tuasnya", "pos": [6.4, 5.3, 10.2], "target": [0, 1.75, 0] }],
  "sfx": [{ "at": "Tuasnya+0.04", "file": "click.mp3", "vol": 0.8 }],     // files in assets/sfx/
  "musik": { "file": "assets/music.mp3", "vol": 0.14 },                  // optional
  "caption_words": 3,
  "near": 0.1, "far": 300            // camera clip range; raise far for big scenes in small units
}
```

- Titles change every 4–6 s, one red keyword each, numbered steps "1 · …" in the mechanism.
- Stickers only on a sound or a reveal (KLIK!, BYUR!, TANPA LISTRIK); y 600–780 keeps them in the stage band.
- Labels appear when the narrator names the part and leave before the next part; anchors are names
  returned by model.js.
- Camera: one key where each move starts, one where it lands (moves 0.6–1.2 s), the gap until the
  next move is a slow drift. Something must change every 1.5–2 s.
- SFX land on their picture (a click on the lever press). Overlapping sounds get their own tracks automatically.

Full example: `<skill>/examples/kloset/episode/beats.json`.

## Editing beats.json

Edit it with a small Python `json.load` / `json.dump`, not sed: dumped JSON spreads arrays over lines,
so text substitutions miss. build.py stops on a window that ends before it starts; read its message.
