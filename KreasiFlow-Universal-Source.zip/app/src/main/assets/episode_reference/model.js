// The object: build its parts once, then move them from state in update(t).
// Return anchors (name -> () => Vector3) for the labels in beats.json.
import { gear, spring } from "../kit/parts.js";
import { angle, cutaway } from "./state.js";

export function build(K) {
  const { THREE } = K;
  K.room({ wallZ: -2, floorY: -0.6 });
  const housing = K.part(K.rbox(3, 1.2, 1.6, 0.08), 0xf2f2ef, { pos: [0, 0, 0], mat: K.mat(0xf2f2ef, { transparent: true }), edgeAngle: 50 });
  const g = gear(K, { teeth: 18, r: 0.5, depth: 0.14, color: 0xf6b40e });
  g.position.set(-0.6, 0, 0);
  const s = spring(K, { radius: 0.16, turns: 7, length: 1.2, color: K.KODE.magnet });
  s.rotation.z = -Math.PI / 2;
  s.position.set(0.1, 0, 0);
  const anchors = { pegas: () => new THREE.Vector3(0.7, 0.2, 0) };
  return {
    anchors,
    update(t) {
      g.rotation.z = -angle(t);
      K.setOpacity(housing, 1 - cutaway(t) * 0.85);
    },
  };
}
