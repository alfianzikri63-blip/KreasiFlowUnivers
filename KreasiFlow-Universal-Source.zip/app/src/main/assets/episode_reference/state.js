// The numbers of the story, as pure functions of t. The model moves parts from these, and the HUD
// shows them, so motion and numbers always agree. Word-anchored times arrive as data.marks.
import { curve, sm } from "../kit/motion.js";

let m = {};
export function init(data) { m = data.marks; }

// gear speed in rpm
export function rpm(t) { return curve([[0, 0], [m.lepas, 0], [m.lepas + 0.4, 110], [m.lepas + 4, 0]], t); }
export function angle(t) {
  // integrate rpm analytically enough for a demo: angle grows with the eased speed curve
  return (rpm(t) / 60) * 2 * Math.PI * Math.max(0, t - m.lepas) * 0.5 * (1 - sm((t - m.lepas - 4) / 0.5));
}
export const cutaway = (t) => sm((t - m.bedah) / 0.8);

export function hud(t) {
  const v = rpm(t);
  return { value: v, status: v > 1 ? "BERPUTAR" : "DIAM", color: v > 1 ? "#c4620f" : "#2a9d5c", sub: "pegas " + (t < m.lepas ? "ditarik" : "lepas") };
}
