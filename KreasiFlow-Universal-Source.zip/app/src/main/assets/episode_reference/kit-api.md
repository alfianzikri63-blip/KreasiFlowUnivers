# Kit API (assets/kit/ in each episode)

## model.js contract

```js
import { gear, spring, screw } from "../kit/parts.js";
import { liters, cutaway } from "./state.js";
export function build(K, { camera, data }) {
  K.room();                          // tiled wall + floor
  const g = K.group([x, y, z]);      // a pivot
  K.part(K.cyl(0.1, 0.1, 1), 0x8c96a2, { pos: [0, 0.5, 0], hull: true, parent: g });
  return {
    anchors: { valve: () => new K.THREE.Vector3(...) },   // names used by labels in beats.json
    update(t) { g.rotation.z = ...; },                     // move parts from state, pure in t
  };
}
```

## state.js contract

```js
let m = {}; export function init(data) { m = data.marks; }   // word times from beats.json "marks"
export function hud(t) { return { value, status, color, sub, text? }; }   // HUD; value also drives the sparkline
```

## look.js: `K` from makeKit(scene)

| Helper | What |
|---|---|
| `K.part(geo, color, {pos, rot, hull, edges, edgeAngle, mat, parent, lineW, name})` | mesh + ink |
| `K.group(pos, parent)` | empty pivot |
| `K.box / K.rbox(w,h,d,r) / K.cyl(rt,rb,h,seg) / K.sphere(r)` | geometries |
| `K.ring(r, tube, color, pos, opts)` | flat torus (seat, rib, gasket) |
| `K.lathe([[r,y],...])` | profile spun around Y (bowl, bottle, pot, piston) |
| `K.extrude([[x,y],...], depth)` | 2D outline with thickness, centred on Z (bracket, blade) |
| `K.tube([[x,y,z],...], r)` | hose, cable, bent pipe |
| `K.mat(color, opts)` | Lambert material |
| `K.cutBox(w,h,d,pos,cutFace,bodyMat)` | wall with a hatched cut face (0 +x,1 -x,2 +y,3 -y,4 +z,5 -z) |
| `K.decal(text, {w,h,px,color,bg})` | printed text plane (spec plate, scale, label) |
| `K.flowLine(color,width)` | x-ray dashed flow; `.setPath(pts)`, `.flow(amount, t, speed)` |
| `K.line(points, color, width, {dashed})` | plain/dashed Line2 (water line, chain, dimension) |
| `K.setOpacity(obj, a)` | fade an object and its ink |
| `K.canvasTex(w,h,draw,repeat)` | texture drawn with canvas 2D |
| `K.KODE` | colour code: panas, aman, magnet, fokus, lebih |

## parts.js

`spring(K,{radius,wire,turns,length})`, `gear(K,{teeth,r,depth,toothDepth,hole})`,
`hexNut(K,{r,h})`, `screw(K,{r,pos})`, `magnet(K,{w,h,d,pos})`, `pipe(K, from, to, {r})`,
`hinge(K, pos, {axis})` (`.swing(rad)`). Add a part here when a second film needs it.

## motion.js

`clamp01, lerp, sm (smoothstep), ease, easeOut, pulse(t,a,b,fade), windows(t,[[a,b]]),
spring(dt,f,z)` (closed-form damped spring), `hash(i,k)` (seeded random), `curve([[t,v],...], t)`.

## camera.js

Keys come from beats.json `kamera`; the runtime interpolates them with a monotone Hermite curve in
spherical coordinates around the target (smooth speed, no overshoot, arcing moves). Two keys close
together = a move; far apart = a slow drift.
