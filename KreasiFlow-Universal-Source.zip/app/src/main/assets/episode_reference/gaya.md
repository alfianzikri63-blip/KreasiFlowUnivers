# Gaya bedah: visual rules

Learned from the reference films (kitabedah.id) and our own tests. Keep a rule only while it earns
its place; add a new one each time a review catches something.

## Colour

- Background room: light grey-beige tiled wall and darker grey floor (`K.room()`); the object must
  separate from it. White objects (ceramic, plastic) need the darker inner faces (`0xd9dcdd`) and the
  tiles behind them, or they dissolve into the paper colour.
- Saturated colour only on the parts the story is about. Everything else: white, grey, charcoal.
- Colour code, the same in every film (`K.KODE`): red heat/electricity, green safe, blue magnet and
  water flow, yellow "this part, now" (light it while the narrator names it, `armFocus` pattern),
  orange hotter than it should be.
- Water: tint from behind (`side: BackSide`) plus a translucent top plane and a blue edge line, so
  parts inside stay crisp. Bubbles as seeded instanced dots.

## Ink

- Near-black `0x15171b`, 4.2 px at 1080 wide (`K.LW`); thinner (2.2–3.2) on small parts.
- Flat faces: `edges` (crease lines, edgeAngle 30–50). Round things: `hull: true` (silhouette).
  Spheres and tori: hull only. A part without either looks pasted on.
- Rendered at pixelRatio 2 (supersampled): lines come out smooth. Don't drop it to 1 for finals.

## Cutaways

- Cut walls are thick and show a hatched section face (`K.cutBox(..., cutFace)`).
- The reveal happens on the words "Kita bedah": front wall slides off and fades, lid lifts away
  (`K.setOpacity` + position, driven by `cutaway(t)`).
- Show the cut where the mechanism is; keep the rest of the shell so the object stays recognisable.

## Framing (9:16, 1080×1920)

- Title and HUD own the top ~470 px (a paper fade covers the 3D there); captions sit at y≈1190–1330.
  The subject lives between, roughly y 520–1180. `viewOffsetY` 150 lifts the picture into that band.
- Portrait has a narrow horizontal field: wide shots need the camera far back (zoom 1.6 with the
  stock keys) or the object is cropped.
- Close-ups fill the band with the part being explained, cropped edges are fine.
- A label must not sit under the title fade or the caption band; flip its `side` or move the camera.
- The final shot must show the hero part of the payoff line (e.g. "Itu pelampung" shows the float).

## Known traps

- Word anchors are case-insensitive: "Air" also matches "air" in "liter air". Run
  `python -I <skill>/scripts/build.py <ep> --words` and use the `word#n` it prints.
- jsDelivr `/+esm` for third-party addons (postprocessing, n8ao, three-bvh-csg) pulls a second copy
  of three. The kit only imports three and three/examples, which is safe.
- Anything that accumulates between frames (TAA, AO accumulation, physics stepped per frame) breaks:
  frames render out of order. Precompute or write closed forms.
- `Math.random` is forbidden; use `hash(i, k)` from motion.js.
- EdgesGeometry on dense or AI-generated meshes draws noise; simplify the mesh first.

## Learned on pentil-ban (judge feedback)

- **Hold the camera still while a small part moves.** If the camera tracks the part, the motion vanishes
  on screen (the seal "went down" in the world but rose in frame). One key where the move starts and the
  same pos/target where it ends.
- **Small motion needs exaggeration:** a 1.4 mm seal travel was invisible; 2 mm plus air dots streaming
  through the gap read at once. Mark such numbers *dimodelkan* in fakta.md.
- **Show flow with moving dots, not only a dashed line.**
- **Anchor a label on the part's visible portion** (the pin tip under the spring, not its top under the
  HUD fade). The runtime fades labels outside the stage band (`bandTop`/`bandBottom` in data), so a label
  anchored off-band silently disappears.
- **Stickers never cover the hero part at its key moment:** move them (`y`) and shrink them (`size`).
- **Payoff frames the hero part centred in the band**, not at the top edge; force arrows must touch the
  part they push.
- **Tiny objects:** pick units to suit (1 = 1 cm for a valve), then `K.room({ scale })` and `near`/`far`
  in beats.json. Open the hook close on the object, then pull out for context, then dive in.
- **Turned parts cut in half:** `latheSection` (with section caps); threads and o-rings: `halfRing`.
