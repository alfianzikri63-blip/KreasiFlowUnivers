KREASIFLOW UNIVERSAL V2.0.1 — AUTO CONTENT (fase 1)
Berdasarkan source V1 API23 Fix; applicationId dan schema metadata tetap.
Fitur: Gemini REST API, konfigurasi model, API key terenkripsi Android Keystore, tes koneksi, lima SKILL.md dari paket renderer V1, pilihan topik opsional, otomatis draft topik/judul/naskah/storyboard/konsep visual/klaim/sumber kandidat/caption/hashtag, autosave dan ekspor draft JSON. Mode manual lama tetap ada.
API key milik pengguna, bukan GitHub secret; kuota/biaya mengikuti provider. Pastikan model tersedia untuk key Anda. Jangan bagikan key. Isi Settings lalu Tes koneksi. Internet wajib saat generate. Biarkan aplikasi terbuka sampai draft muncul. Generate ulang membuat project baru, tidak menimpa project lama.
Sumber kandidat belum diverifikasi, belum ada grounding web. Model 3D, voice, timeline executable, QC, auto dispatch/polling GitHub dan render MP4 otomatis belum diimplementasikan. Tidak ada klaim keberhasilan render.
Build Android belum dijalankan lokal (SDK dan Gradle tidak tersedia). GitHub Actions akan melakukan assembleRelease, lintRelease, signing dan publish jika berhasil. Jangan ubah dua secret lama atau applicationId.
Dokumentasi Gemini: https://ai.google.dev/gemini-api/docs/generate-content/text-generation
