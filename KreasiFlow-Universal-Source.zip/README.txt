KreasiFlow Universal V2.3.0 — One Click Video Draft Beta
Android minSdk 23, targetSdk 34, compileSdk 35. Build via GitHub Actions paket luar.
One Click menggunakan Gemini + EpisodeBuilder + workflow renderer V2.2. Simpan kredensial di Settings saja. Status tahapan tersimpan di project, pemantauan foreground, resume dari Projects. MP4 draft hanya dinyatakan tersedia setelah workflow sukses dan track audio/video diperiksa. Review sumber, kode, visual, suara sebelum posting. Mode manual tetap tersedia. Belum diuji end-to-end atau dikompilasi dalam sesi ini.
